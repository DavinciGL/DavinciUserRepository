# DAVINCI GL
*The minimal and high peformance and easy to use Graphics API!*

Davinci-GL is a incredibly simple to use Graphics API, it is being developed to be an alternative to OpenGL's simplicity and Vulkans low overhead.

It is written in C/C++, mostly in C, and is mainly built for the x86_64 architecture, but you can build the source code and make it use YOUR architecture!

To use Davinci-GL in your Projects, just include the library.h file in your Project. It will give you the functions.

# DOCUMENTATION
**makeWindow();**

makeWindow creates a window usinng the Windows API, you will need to put in your X,Y,Z size variables. For more info, check the Windows API Documentation.

**closeWindow();**
closeWindow shuts and terminates the window, it takes the windowName as a parameter. Easy.

**PLEASE NOTE, THIS IS AN EARLY VERSION OF DAVINCI-GL, USAGE MAY CHANGE AND NEW FUNCTIONS WILL BE ADDED AND SOME WILL BE DEPRECATED.**
